# Multiplayer bowling game


## ER Diagram:
![ER Diagram](https://raw.githubusercontent.com/shubh1m/multiplayer-bowling-game/master/IMG_20191101_142130.jpg)
