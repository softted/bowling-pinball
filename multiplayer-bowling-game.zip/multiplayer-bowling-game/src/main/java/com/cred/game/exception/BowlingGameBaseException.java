package com.cred.game.exception;

public class BowlingGameBaseException extends RuntimeException {
}
