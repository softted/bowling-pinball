package com.cred.game.exception;

public class LaneNotAvailableException extends RuntimeException {

}
