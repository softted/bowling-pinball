package com.cred.game.lane;

public enum LaneStatus {
	AVAILABLE,
	IN_USE,
	UNAVAILABLE
}
